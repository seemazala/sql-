--Table- 1 Location Table

Create Table LocationTable
(
Location_Id int PRIMARY KEY,
City Varchar(30)
);

Insert into LocationTable (Location_Id, City)Values
(122,'New York'),
(123,'Dallas'),
(124,'Chicago'),
(167,'Botson');

Select *From LocationTable;

--Table -2 Department
Create Table Department
(
Department_Id int PRIMARY KEY,
Name varchar(30),
Location_Id int,
FOREIGN KEY (Location_Id) REFERENCES LocationTable(Location_Id)
);

Insert into Department values
(10,'Accounting',122),
(20,'Sales',124),
(30,'Research',123),
(40,'Operations',167);

Select * from Department;

--Table- 3 Job Table
Create Table Job
(
Job_Id int PRIMARY KEY,
Designation varchar(30)
);

Insert into Job (Job_Id,Designation)Values
(667,'Clerk'),
(668,'Staff'),
(669,'Analyst'),
(670,'Sales Person'),
(671,'Manager'),
(672,'President');

Select * from Job;

--Table- 4 Employee Table
Create Table Employee
(
Employee_Id int PRIMARY KEY,
Last_Name varchar(30),
First_Name varchar(30),
Middel_Name varchar(1),
Job_Id INT,
Hire_Date Date,
Salary int,
Comm int,
Department_Id int,
FOREIGN KEY (Job_Id) REFERENCES JOB(Job_Id),
FOREIGN KEY (Department_Id) REFERENCES Department(Department_Id)
);

INSERT INTO Employee VALUES
(7369, 'Smith', 'John', 'Q', 667, '1984-12-17', 800, NULL, 20),
(7499, 'Allen', 'Kevin', 'J', 670, '1985-02-20', 1600, 300, 30),
(7550, 'Doyle', 'Jean', 'K', 671, '1985-04-04', 2850, NULL, 30),
(7551, 'Dennis', 'Lynn', 'S', 671, '1985-05-15', 2750, NULL, 30),
(7552, 'Baker', 'Leslie', 'D', 671, '1985-06-10', 2200, NULL, 40),
(7521, 'Wark', 'Cynthia', 'D', 670, '1985-02-22', 1250, 50, 30);

Select *from Employee;
--Simple Queries..
--1.List all the employee details. 
Select *from Employee;

--2. List all the department details.
Select *From Department;

--3. List all job details. 
Select *From Job;

--4. List all the locations.
Select *From LocationTable;

--5.List out the First Name, Last Name, Salary, Commission for all Employees. 
Select First_Name, Last_Name,Salary,Comm From Employee;

--6.List out the Employee ID, Last Name, Department ID for all employees and alias 
--Employee ID as "ID of the Employee", Last Name as "Name of the Employee", Department ID as "Dep_id". 
Select Employee_Id AS "ID Of The Employee",
	   Last_Name  AS "Name Of The Employee",
	   Department_Id AS "Dep_id" From Employee;

--7.List out the annual salary of the employees with their names only.
Select First_Name,Last_Name ,(Salary*12) AS Annual_Salary From Employee;

--Where Condition
--1. List the details about "Smith". 
select *from Employee Where Last_Name = 'smith';

--2. List out the employees who are working in department 20.
Select *from Employee Where Department_Id = 20;

--3. List out the employees who are earning salary between 2000 and 3000. 
Select *from Employee Where Salary BETWEEN 2000 AND 3000;

--4. List out the employees who are working in department 10 or 20.
Select *from Employee Where Department_Id IN (10,20);

--5. Find out the employees who are not working in department 10 or 30. 
Select *from Employee Where Department_Id NOT IN(10,30);

--6. List out the employees whose name starts with 'L'.
Select *from Employee Where First_Name LIKE 'L%';

--7. List out the employees whose name starts with 'L' and ends with 'E'. 
Select *from Employee Where First_Name Like 'L%E'; 

--8. List out the employees whose name length is 4 and start with 'J'. 
Select *from Employee Where First_Name Like 'J___';

--9. List out the employees who are working in department 30 and draw the salaries more than 2500.
Select *from Employee Where Department_Id = 30 AND Salary>2500 ;

--10. List out the employees who are not receiving commission.
Select *from Employee Where Comm IS Null;

-- ORDER BY CLAUSE

--1. List out the Employee ID and Last Name in ascending order based on the Employee ID.
Select Employee_Id,Last_Name From Employee ORDER BY Employee_Id ASC;

--2. List out the Employee ID and Name in descending order based on salary. 
Select Employee_Id,First_Name, from Employee ORDER BY Salary DESC;

--3. List out the employee details according to their Last Name in ascending-order.
Select *From Employee ORDER BY Last_Name ASC;

--4. List out the employee details according to their Last Name in ascending order and then Department ID in descending order.
Select *From Employee ORDER BY Last_Name ASC, Department_Id DESC;

--GROUP BY AND HAVING CLAUSE
--1. List out the department wise maximum salary, minimum salary and average salary of the employees. 
Select Department_Id ,
	MAX(Salary)AS Max_Salary,
	MIN(Salary)AS Min_Salary,
	AVG(Salary)AS Avg_Salary
	From Employee GROUP BY Department_Id;

--2. List out the job wise maximum salary, minimum salary and average salary of the employees. 
Select Job_Id,
	MAX(Salary)AS Max_Salary,
	MIN(Salary)AS Min_Salary,
	AVG(Salary)AS Avg_Salary
	From Employee GROUP BY Job_Id;

--3. List out the number of employees who joined each month in ascending order.
Select Month(Hire_Date)AS Month,COUNT(*) AS Count From Employee
GROUP BY Month(Hire_Date) ORDER BY Month;

--4. List out the number of employees for each month and year in ascending order based on the year and month.
Select Month(Hire_Date)AS Month,Year(Hire_Date)AS Year ,COUNT(*) AS Count From Employee
GROUP BY Month(Hire_Date) ,Year(Hire_Date) ORDER BY Year,Month;

--5. List out the Department ID having at least four employees. 
Select Department_id From Employee 
GROUP BY Department_Id
HAVING COUNT(*)>=4;

--6. How many employees joined in February month. 
Select COUNT (*) From Employee Where Month(Hire_Date) = 2;

--7. How many employees joined in May or June month. 
Select COUNT (*) From Employee Where Month(Hire_Date) IN (5,6);

--8. How many employees joined in 1985? 
Select COUNT (*) From Employee Where Year(Hire_Date) = 1985;

--9. How many employees joined each month in 1985? 
Select Month(Hire_Date),COUNT (*) From Employee 
Where Year(Hire_Date) = 1985
GROUP BY MONTH(Hire_Date);

--10. How many employees were joined in April 1985?
Select COUNT (*) From Employee
Where Month(Hire_Date) = 4 AND YEAR(Hire_Date)= 1985 ;

--11. Which is the Department ID having greater than or equal to 3 employees joining in April 1985? 
Select Department_Id From Employee
Where Month(Hire_Date) = 4
AND YEAR(Hire_Date)=1985
GROUP BY Department_Id
HAVING COUNT(*)>=3;

--JOINS
--1. List out employees with their department names. 
Select E.First_Name,E.Last_Name,D.Name AS Department
From Employee E 
JOIN 
Department D ON E.Department_Id = D.Department_Id;

--2. Display employees with their designations. 
Select E.First_Name,E.Last_Name,J.Designation
From Employee E
JOIN 
Job J ON E.Job_Id = J.Job_Id;

--3. Display the employees with their department names and city. 
SELECT E.First_Name, E.Last_Name, D.Name AS Department, L.City
FROM Employee E
JOIN Department D ON E.Department_Id = D.Department_Id
JOIN LocationTable L ON D.Location_Id = L.Location_ID;

--4. How many employees are working in different departments? Display with department names. 
SELECT D.Name AS Department, COUNT(*) AS Num_Employees
FROM Employee E
JOIN Department D ON E.Department_Id = D.Department_Id
GROUP BY D.Name;

--5. How many employees are working in the sales department? 
SELECT COUNT(*)
FROM Employee E
JOIN Department D ON E.Department_Id = D.Department_Id
WHERE D.Name = 'Sales';

--6. Which is the department having greater than or equal to 3 employees and display the department names in ascending order. 
SELECT D.Name
FROM Employee E
JOIN Department D ON E.Department_Id = D.Department_Id
GROUP BY D.Name
HAVING COUNT(*) >= 3
ORDER BY D.Name;

--7. How many employees are working in 'Dallas'? 
SELECT COUNT(*)
FROM Employee E
JOIN Department D ON E.Department_Id = D.Department_Id
JOIN LocationTable L ON D.Location_Id = L.Location_ID
WHERE L.City = 'Dallas';

--8. Display all employees in sales or operation departments.
SELECT E.*
FROM Employee E
JOIN Department D ON E.Department_Id = D.Department_Id
WHERE D.Name IN ('Sales', 'Operations');

--Conditional Statement
--1.Display the employee details with salary grades. Use conditional statement to create a grade column. 
Select *, 
  CASE 
    WHEN Salary < 1000 THEN 'Grade D'
    WHEN Salary BETWEEN 1000 AND 1999 THEN 'Grade C'
    WHEN Salary BETWEEN 2000 AND 2999 THEN 'Grade B'
    ELSE 'Grade A'
  END AS Grade
FROM Employee;

--2. List out the number of employees grade wise. Use conditional statement to create a grade column. 
Select
  CASE 
    WHEN Salary < 1000 THEN 'Grade D'
    WHEN Salary BETWEEN 1000 AND 1999 THEN 'Grade C'
    WHEN Salary BETWEEN 2000 AND 2999 THEN 'Grade B'
    ELSE 'Grade A'
  END AS Grade,
  COUNT(*) AS Num_Employees
FROM Employee
GROUP BY 
  CASE 
    WHEN Salary < 1000 THEN 'Grade D'
    WHEN Salary BETWEEN 1000 AND 1999 THEN 'Grade C'
    WHEN Salary BETWEEN 2000 AND 2999 THEN 'Grade B'
    ELSE 'Grade A'
  END;

--3. Display the employee salary grades and the number of employees between 2000 to 5000 range of salary.
SELECT 
  CASE 
    WHEN Salary BETWEEN 2000 AND 2999 THEN 'Grade B'
    ELSE 'Grade A'
  END AS Grade,
  COUNT(*) AS Num_Employees
FROM Employee
WHERE Salary BETWEEN 2000 AND 5000
GROUP BY 
  CASE 
    WHEN Salary BETWEEN 2000 AND 2999 THEN 'Grade B'
    ELSE 'Grade A'
  END;

--Subqueries
--1. Display the employees list who got the maximum salary. 
Select * From Employee
Where Salary = (Select MAX(Salary) From Employee)

--2. Display the employees who are working in the sales department. 
Select * From Employee
WHERE Department_Id = (Select Department_Id FROM Department WHERE Name = 'Sales');

--3. Display the employees who are working as 'Clerk'. 
Select * From Employee
WHERE Job_Id = (Select Job_Id FROM JOB WHERE Designation = 'Clerk');

--4. Display the list of employees who are living in 'Boston'. 
Select E.*
FROM Employee E
JOIN Department D ON E.Department_Id = D.Department_Id
WHERE D.Location_Id = (Select Location_ID FROM LocationTable WHERE City = 'Boston');

--5. Find out the number of employees working in the sales department. 
Select COUNT(*) From Employee
WHERE Department_Id = (Select Department_Id FROM Department WHERE Name = 'Sales');

--6. Update the salaries of employees who are working as clerks on the basis of 10%. 
UPDATE Employee
SET Salary = Salary * 1.10
WHERE Job_Id = (Select Job_ID FROM Job WHERE Designation = 'Clerk');

--7. Display the second highest salary drawing employee details. 
Select * From Employee
WHERE Salary = (
  SELECT MAX(Salary)
  FROM EMPLOYEE
  WHERE Salary < (SELECT MAX(Salary) FROM EMPLOYEE)
);

--8. List out the employees who earn more than every employee in department 30. 
Select * From Employee
WHERE Salary > ALL (
  SELECT Salary FROM Employee WHERE Department_Id = 30
);

--9. Find out which department has no employees. 
Select * From Department
WHERE Department_Id NOT IN (Select DISTINCT Department_Id FROM Employee);

--10.Find out the employees who earn greater than the average salary for their department.
Select * from Employee E
WHERE Salary > (
  Select AVG(Salary)
  FROM Employee
  WHERE Department_Id = E.Department_Id
);
