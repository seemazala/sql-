create database assignment_3;

CREATE TABLE Jomaato (
    RestaurantID INT,
    RestaurantName VARCHAR(255),
    Cuisinetype VARCHAR(255),
    RestaurantType VARCHAR(100),
    Rating FLOAT,
    AverageCost INT,
    RatingCount INT,
	Area varchar(30),
	Table_booking int
);

INSERT INTO Jomaato (RestaurantID, RestaurantName, CuisineType, RestaurantType, Rating, RatingCount, AverageCost,Area,Table_booking)
VALUES 
(1,'DOSA HOUSE','Indian','Quick Bite',4.5,300,400,'vasant Kunj Road',5),
(2,'Kitchen Age', 'Indian','quick Bite',4.4,250,300,'Dwarka Road ',2),
(3,'U.S.Pizza','America','Causal Dinning',4.4,250,300,'Rajkot City Centre',3),
(4,'Celebration','cafe','quick bite',5,400,500,'Jamnager Reliance Road',1),
(5,'Food World','Indian','Quick Bite',5,400,500,'Digvijay Plot',4);

select * from jomaato;

--TASK -->

--1. Create a stored procedure to display the restaurant name, type and cuisine where the table booking is not zero.

Create PROCEDURE GetRestaurantWithTableBooking
AS
BEGIN
	Select RestaurantName, RestaurantType, CuisineType From Jomaato
	Where Table_booking > 0 ;
END;

EXEC GetRestaurantWithTableBooking;

--2.Create a transaction and update the cuisine type �Cafe� to �Cafeteria�. Check the result and rollback it.

begin Transaction 

Update Jomaato
set Cuisinetype = 'cafeteria'
Where Cuisinetype = 'Cafe';

Select *From Jomaato Where Cuisinetype = 'cafeteria';

RollBack;

Select *from Jomaato where Cuisinetype = 'Cafe';

--3.Generate a row number column and find the top 5 areas with the highest rating of restaurants

With AreaRating As(
	Select Area, 
	Avg(Rating) As AVGRating
    From Jomaato 
	Group By Area
),

RankedArea As(
	Select Area, AVGRating,
	ROW_NUMBER() Over (order by AvgRating DESC) AS Row_Num
	From AreaRating
)
Select * From RankedArea Where Row_num <= 5;

--4.Use the while loop to display the 1 to 50.

Declare @num int=1;
While @num <= 50 
BEGIN 
	Print @num;
	set @num = @num + 1;
End;

--5.Write a query to Create a Top rating view to store the generated top 5 highest rating of restaurants.

Create View Top5RatedResataurant AS
Select Top 5 RestaurantName, Rating, Area From Jomaato
Order by Rating DESC;

--6.Create a trigger that give an message whenever a new record is inserted.

Create TRIGGER Trg_Restaurant_Insert
ON Jomaato
After Insert 
AS Begin 
	Print 'A New Restaurant Inserted.';
End;

insert into jomaato (RestaurantID, RestaurantName, CuisineType, RestaurantType, Rating, RatingCount, AverageCost,Area,Table_booking)
VALUES 
(6,'Thakker Food','Indian','Multi Cousion',5.5,300,400,'ridhi sidhi Road',6);