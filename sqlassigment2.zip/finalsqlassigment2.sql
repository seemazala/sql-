create database assigment_2;
 --You work for a data analytics company, and your client is a food delivery platform similar to
 --Jomato. They have provided you with a dataset containing information about various
 --restaurants in a city. Your task is to analyze this dataset using SQL queries to extract valuable
 --insights and generate reports for your client.

CREATE TABLE Jomato (
    RestaurantID INT,
    RestaurantName VARCHAR(255),
    CuisineType VARCHAR(255),
    RestaurantType VARCHAR(100),
    Rating FLOAT,
    AverageCost INT,
    RatingCount INT
);

INSERT INTO Jomato (RestaurantID, RestaurantName, CuisineType, RestaurantType, Rating, RatingCount, AverageCost)
VALUES 
(1,'DOSA HOUSE','Indian','Quick Bite',4.5,300,400),
(2,'Kitchen Age', 'Indian','quick Bite',4.4,250,300),
(3,'U.S.Pizza','America','Causal Dinning',4.4,250,300),
(4,'Celebration','indian','Fine Dinning',5,400,500),
(5,'Food World','Indian','Quick Bite',5,400,500);

select * from jomato;

--1.  Create a user-defined functions to stuff the Chicken into �Quick Bites�. Eg: �Quick
 --Chicken Bites�.

CREATE FUNCTION dbo.StuffChicken (@input NVARCHAR(100))
RETURNS NVARCHAR(100)
AS
BEGIN
    DECLARE @result NVARCHAR(100)
    -- Replace 'Quick Bites' with 'Quick Chicken Bites'
    SET @result = REPLACE(@input, 'Quick Bites', 'Quick Chicken Bites')
    RETURN @result
END;

--2.  Use the function to display the restaurant name and cuisine type which has the
 --maximum number of rating.

SELECT 
    RestaurantName,
    CuisineType,
    dbo.StuffChicken(RestaurantType) AS ModifiedRestaurantType
FROM Jomato
WHERE RatingCount = (
    SELECT MAX(RatingCount) FROM Jomato
);

--3.  Create a Rating Status column to display the rating as �Excellent� if it has more the 4
 --start rating, �Good� if it has above 3.5 and below 4 star rating, �Average� if it is above 3
 --and below 3.5 and �Bad� if it is below 3 star rating and

SELECT 
    RestaurantName,
    Rating,
    CASE 
        WHEN Rating > 4 THEN 'Excellent'
        WHEN Rating > 3.5 THEN 'Good'
        WHEN Rating > 3 THEN 'Average'
        ELSE 'Bad'
    END AS RatingStatus
FROM Jomato;

--4. Find the Ceil, floor and absolute values of the rating column and display the current
--date and separately display the year, month_name and day.

SELECT 
    RestaurantName,
    Rating,
    CEILING(Rating) AS CeilRating,
    FLOOR(Rating) AS FloorRating,
    ABS(Rating) AS AbsoluteRating,
    GETDATE() AS CurrentDate,
    YEAR(GETDATE()) AS Year,
    DATENAME(MONTH, GETDATE()) AS MonthName,
    DAY(GETDATE()) AS Day
FROM Jomato;



--5. Display the restaurant type and total average cost using rollup.

SELECT 
    RestaurantType,
    SUM(AverageCost) AS TotalAverageCost
FROM Jomato
GROUP BY ROLLUP(RestaurantType);